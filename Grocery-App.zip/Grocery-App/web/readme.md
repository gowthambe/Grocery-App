# Grocery Flutter Web App 


<img src="https://github.com/Widle-Studio/Grocery-App/blob/master/web/mainpage.png" alt="Grocery Flutter Web - Home" height="1000" width="600">

<img src="https://github.com/Widle-Studio/Grocery-App/blob/master/web/details.png" alt="Grocery Flutter Web - Details" height="1000" width="600">

<img src="https://github.com/Widle-Studio/Grocery-App/blob/master/web/filter.png" alt="Grocery Flutter Web - Filter" height="900" width="600">

<img src="https://github.com/Widle-Studio/Grocery-App/blob/master/web/checkout.png" alt="Grocery Flutter Web - Checkout" height="900" width="600">

<img src="https://github.com/Widle-Studio/Grocery-App/blob/master/web/payment.png" alt="Grocery Flutter Web - Payment" height="900" width="600">

<img src="https://github.com/Widle-Studio/Grocery-App/blob/master/web/delivery.png" alt="Grocery Flutter Web - Delivery" height="900" width="600">

<img src="https://github.com/Widle-Studio/Grocery-App/blob/master/web/oreder.png" alt="Grocery Flutter Web - Order" height="900" width="600">

<img src="https://github.com/Widle-Studio/Grocery-App/blob/master/web/profile.png" alt="Grocery Flutter Web - Profile" height="900" width="600">
